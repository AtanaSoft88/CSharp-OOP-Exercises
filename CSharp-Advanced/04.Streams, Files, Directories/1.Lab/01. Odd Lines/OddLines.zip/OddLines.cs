﻿
namespace OddLines
{
    using System;
    using System.IO;
    public class OddLines
    {
        static void Main()
        {
            string inputPath = @"..\..\..\Files\input.txt";
            string outputPath = @"..\..\..\Files\output.txt";

            ExtractOddLines(inputPath, outputPath);
        }

        public static void ExtractOddLines(string inputFilePath, string outputFilePath)
        {
            using (StreamWriter strmWriter = new StreamWriter(outputFilePath))
            {
                
                using (StreamReader strmReader = new StreamReader(inputFilePath))
                {
                    string readTxt = strmReader.ReadLine();
                   int index = 0;

                    while (readTxt != null)
                    {
                        if (index %2 != 0)
                        {
                            strmWriter.WriteLine(readTxt);
                        }
                        readTxt = strmReader.ReadLine();

                        index++;
                    }
                }
            }

            
        }
    }
}
