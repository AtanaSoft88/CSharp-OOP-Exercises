﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BoxOfT
{
    public class Box<T>
    {
        //•	void Add(element) – adds an element on the top of the list.
        //•	element Remove() – removes the topmost element.
        //•	int Count { get; }

        private List<T> elementsList;

        public Box()
        {
            elementsList = new List<T>();
        }
        public int Count { get => elementsList.Count; }

       
        public void Add(T element)
        {
            
            elementsList.Add(element);
        
        
        }
        
        public T Remove()
        {
            
            T tempElement = elementsList.LastOrDefault();

            elementsList.Remove(tempElement);

            return tempElement;
        
        
        }
    }
}
