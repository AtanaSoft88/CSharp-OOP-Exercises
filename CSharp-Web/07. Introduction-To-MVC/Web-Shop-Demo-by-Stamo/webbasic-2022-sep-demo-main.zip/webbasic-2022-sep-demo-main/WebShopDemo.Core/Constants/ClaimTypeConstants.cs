﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebShopDemo.Core.Constants
{
    public static class ClaimTypeConstants
    {
        public const string FirsName = "urn:softuni:webshop:firstName";
    }
}
