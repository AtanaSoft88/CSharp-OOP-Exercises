﻿namespace WebShopDemo.Core.Constants
{
    public static class RoleConstants
    {
        public const string Manager = "Manager";
        public const string Supervisor = "Supervisor";
        public const string Administrator = "Administrator";
    }
}
